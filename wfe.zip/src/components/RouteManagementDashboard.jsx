import React, { useState } from 'react';
import { usePickup } from '../contexts/PickupContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Plus, Edit, Trash2, Route, Clock, ClipboardList } from 'lucide-react';
import { motion } from 'framer-motion';

const RouteManagementDashboard = ({ onCreateRoute, onUpdateRoute, onDeleteRoute }) => {
  const { routes, assignments } = usePickup();

  const totalRoutes = routes.length;
  const totalRoutesAssignedForAssignment = new Set(assignments.map(assignment => assignment.routeId)).size;
  const avgEstimatedTime = routes.length > 0 
    ? (routes.reduce((sum, route) => {
        const timeParts = route.estimatedTime.match(/(\d+)\s*(hour|minute)s?/);
        if (timeParts) {
          const value = parseInt(timeParts[1]);
          const unit = timeParts[2];
          return sum + (unit === 'hour' ? value * 60 : value);
        }
        return sum;
      }, 0) / routes.length).toFixed(0) + ' minutes'
    : 'N/A';

  const stats = [
    {
      title: 'Total Routes',
      value: totalRoutes,
      icon: Route,
      color: 'text-blue-600 dark:text-blue-400',
      bgColor: 'bg-blue-100 dark:bg-blue-900'
    },
    {
      title: 'Routes Assigned for Assignment',
      value: totalRoutesAssignedForAssignment,
      icon: ClipboardList,
      color: 'text-green-600 dark:text-green-400',
      bgColor: 'bg-green-100 dark:bg-green-900'
    },
    {
      title: 'Avg. Estimated Time',
      value: avgEstimatedTime,
      icon: Clock,
      color: 'text-purple-600 dark:text-purple-400',
      bgColor: 'bg-purple-100 dark:bg-purple-900'
    },
  ];

  return (
    <div className="p-2 sm:p-4 lg:p-6 max-w-full overflow-hidden">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="space-y-4 sm:space-y-6"
      >
        <h1 className="text-xl sm:text-2xl lg:text-3xl font-bold text-gray-800 dark:text-white">Route Management</h1>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4 lg:gap-6">
          {stats.map((stat, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1, duration: 0.6 }}
              className="w-full"
            >
              <Card className="transition-all duration-200 hover:scale-105 hover:shadow-lg w-full">
                <CardContent className="p-3 sm:p-4 lg:p-6">
                  <div className="flex items-center justify-between">
                    <div className="min-w-0 flex-1">
                      <p className="text-xs sm:text-sm font-medium text-muted-foreground truncate">{stat.title}</p>
                      <p className="text-lg sm:text-xl lg:text-2xl font-bold">{stat.value}</p>
                    </div>
                    <div className={`p-2 sm:p-3 rounded-full ${stat.bgColor} flex-shrink-0 ml-2`}>
                      <stat.icon className={`h-4 w-4 sm:h-5 sm:w-5 lg:h-6 lg:w-6 ${stat.color}`} />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Action Buttons - Centered */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.6 }}
          className="flex justify-center w-full"
        >
          <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 w-full max-w-4xl">
            <Button 
              onClick={onCreateRoute} 
              className="w-full sm:flex-1 h-10 sm:h-12 text-sm sm:text-base lg:text-lg text-white transition-all duration-200 hover:scale-105 bg-green-600 hover:bg-green-700"
            >
              <Plus className="mr-2 h-4 w-4 sm:h-5 sm:w-5" /> Create Route
            </Button>
            <Button 
              onClick={() => onUpdateRoute()} 
              className="w-full sm:flex-1 h-10 sm:h-12 text-sm sm:text-base lg:text-lg text-white dark:text-white transition-all duration-200 hover:scale-105 bg-yellow-500 hover:bg-yellow-600"
            >
              <Edit className="mr-2 h-4 w-4 sm:h-5 sm:w-5" /> Update Route
            </Button>
            <Button 
              onClick={() => onDeleteRoute()} 
              className="w-full sm:flex-1 h-10 sm:h-12 text-sm sm:text-base lg:text-lg text-white transition-all duration-200 hover:scale-105 bg-red-500 hover:bg-red-700"
            >
              <Trash2 className="mr-2 h-4 w-4 sm:h-5 sm:w-5" /> Delete Route
            </Button>
          </div>
        </motion.div>

        {/* Routes Table */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6, duration: 0.6 }}
          className="w-full"
        >
          <Card className="w-full">
            <CardHeader className="p-3 sm:p-4 lg:p-6">
              <CardTitle className="text-sm sm:text-base lg:text-lg">All Routes</CardTitle>
            </CardHeader>
            <CardContent className="p-0 sm:p-3 lg:p-6 sm:pt-0 lg:pt-0">
              <div className="overflow-x-auto w-full">
                <Table className="min-w-full">
                  <TableHeader>
                    <TableRow>
                      <TableHead className="text-xs sm:text-sm whitespace-nowrap px-2 sm:px-4">Route ID</TableHead>
                      <TableHead className="text-xs sm:text-sm whitespace-nowrap px-2 sm:px-4 hidden sm:table-cell">Zone ID</TableHead>
                      <TableHead className="text-xs sm:text-sm whitespace-nowrap px-2 sm:px-4">Route Name</TableHead>
                      <TableHead className="text-xs sm:text-sm whitespace-nowrap px-2 sm:px-4 hidden md:table-cell">Path Details</TableHead>
                      <TableHead className="text-xs sm:text-sm whitespace-nowrap px-2 sm:px-4 hidden lg:table-cell">Avg. Est. Time</TableHead>
                      <TableHead className="text-xs sm:text-sm whitespace-nowrap px-2 sm:px-4">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {routes.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center py-6 sm:py-8 text-muted-foreground text-xs sm:text-sm">
                          No routes available.
                        </TableCell>
                      </TableRow>
                    ) : (
                      routes.map((route) => (
                        <TableRow key={route.id} className="hover:bg-muted/50">
                          <TableCell className="text-xs sm:text-sm px-2 sm:px-4 whitespace-nowrap font-medium">{route.id}</TableCell>
                          <TableCell className="text-xs sm:text-sm px-2 sm:px-4 whitespace-nowrap hidden sm:table-cell">{route.zoneId}</TableCell>
                          <TableCell className="text-xs sm:text-sm px-2 sm:px-4 whitespace-nowrap">{route.name}</TableCell>
                          <TableCell className="text-xs sm:text-sm px-2 sm:px-4 whitespace-nowrap hidden md:table-cell max-w-xs truncate" title={route.pathDetails}>{route.pathDetails}</TableCell>
                          <TableCell className="text-xs sm:text-sm px-2 sm:px-4 whitespace-nowrap hidden lg:table-cell">{route.estimatedTime}</TableCell>
                          <TableCell className="px-2 sm:px-4">
                            <div className="flex space-x-1 sm:space-x-2">
                              <Button variant="outline" size="sm" onClick={() => onUpdateRoute(route.id)} className="h-7 w-7 sm:h-8 sm:w-8 p-0">
                                <Edit className="h-3 w-3 sm:h-4 sm:w-4" />
                              </Button>
                              <Button variant="outline" size="sm" onClick={() => onDeleteRoute(route.id)} className="h-7 w-7 sm:h-8 sm:w-8 p-0">
                                <Trash2 className="h-3 w-3 sm:h-4 sm:w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
              
              {/* Mobile-friendly route cards for very small screens */}
              <div className="block sm:hidden mt-4">
                {routes.length > 0 && (
                  <div className="space-y-3">
                    <h3 className="text-sm font-medium text-muted-foreground px-3">Route Details</h3>
                    {routes.map((route) => (
                      <Card key={`mobile-${route.id}`} className="mx-3">
                        <CardContent className="p-3">
                          <div className="space-y-2">
                            <div className="flex justify-between items-start">
                              <div className="flex-1 min-w-0">
                                <p className="font-medium text-sm truncate">{route.name}</p>
                                <p className="text-xs text-muted-foreground">ID: {route.id}</p>
                              </div>
                              <div className="flex space-x-1 ml-2">
                                <Button variant="outline" size="sm" onClick={() => onUpdateRoute(route.id)} className="h-7 w-7 p-0">
                                  <Edit className="h-3 w-3" />
                                </Button>
                                <Button variant="outline" size="sm" onClick={() => onDeleteRoute(route.id)} className="h-7 w-7 p-0">
                                  <Trash2 className="h-3 w-3" />
                                </Button>
                              </div>
                            </div>
                            <div className="text-xs text-muted-foreground space-y-1">
                              <p>🏷️ Zone: {route.zoneId}</p>
                              <p>🛣️ Path: {route.pathDetails}</p>
                              <p>⏱️ Est. Time: {route.estimatedTime}</p>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>
    </div>
  );
};

export default RouteManagementDashboard;

